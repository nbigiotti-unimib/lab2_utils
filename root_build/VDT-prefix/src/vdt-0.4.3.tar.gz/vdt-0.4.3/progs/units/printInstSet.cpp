/*
 * printInstSet.cpp
 *
 *  Created on: Jun 23, 2012
 *      Author: danilopiparo
 */
#include "vdtdiag_helper.h"

using namespace vdth;

int main(){
	print_instructions_info();
}



